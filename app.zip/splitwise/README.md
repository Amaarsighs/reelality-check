# Reel-ality Check

A cognitive-assistive mobile application designed to quantify and mitigate algorithmic bias in short-form video consumption. By leveraging Asynchronous Screen-Scraping, Heuristic Intent Detection, and Non-Parametric Classification, the system provides users with empirical insights into their "Content Tilt"—the ideological or thematic deviation of their media diet.

## System Architecture

### Front-End
- **Framework**: Cross-platform Flutter
- **State Management**: BLoC (Business Logic Component) pattern
- **UI Components**: Material Design with custom SVG charts

### Service Layer (Android)
- **Accessibility Service API**: Context-aware background monitoring
- **MediaProjection API**: Frame/audio capture with user consent
- **Background Service**: Persistent monitoring and notification scheduling

### Backend Orchestration
- **API**: RESTful API (Flask/Python)
- **Inference Engine**: Scikit-learn implementation
  - k-Nearest Neighbors (k=3) for content classification
  - K-Means Clustering for trend discovery

## Key Features

### 1. Contextual State Detection & Data Acquisition
- **FR-1**: AccessibilityService monitoring of Instagram Reels
- **FR-2**: UI-driven triggering via pixel-color comparison
- **FR-3**: Multimodal feature extraction (ASR + OCR)

### 2. Machine Learning Inference
- **FR-4**: TF-IDF vectorization for feature extraction
- **FR-5**: k-NN classification (k=3, Euclidean distance)
- **FR-6**: 72-hour K-Means clustering for trend discovery

### 3. Reporting & Logic
- **FR-7**: Tilt Index calculation based on cluster variance
- **FR-8**: Scheduled notifications every 72 hours
  - Alert State: High bias detected
  - Equilibrium State: Balanced content diet

## Technical Specifications

### Non-Functional Requirements
- **NFR-1**: Ephemeral data processing (24-hour retention)
- **NFR-2**: RTT < 8.0 seconds for classification
- **NFR-3**: Low-frequency polling for minimal resource usage
- **NFR-4**: TLS 1.3 encryption for all API communications

### Performance Metrics
- **Classification Latency**: < 8 seconds
- **Memory Usage**: Optimized for mobile devices
- **Battery Impact**: Minimal through efficient polling
- **Data Privacy**: Local processing with encrypted transmission

## Installation & Setup

### Prerequisites
- Flutter SDK >= 3.10.0
- Android SDK (API level 21+)
- Python 3.8+ (for backend)
- Redis (optional, for production caching)

### Frontend Setup
```bash
# Clone the repository
git clone <repository-url>
cd reel-ality-check

# Install Flutter dependencies
flutter pub get

# Run the app
flutter run
```

### Backend Setup
```bash
# Navigate to backend directory
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the Flask server
python app.py
```

### Android Configuration
1. Enable developer options on your device
2. Grant Accessibility Service permission
3. Grant Overlay permission
4. Grant Storage and Microphone permissions

## Usage

### 1. Start Monitoring
- Open the app and navigate to the Monitor tab
- Grant all required permissions
- Tap "Start Monitoring" to begin content analysis

### 2. View Insights
- Navigate to the Insights tab
- View your Content Tilt Index
- Analyze category distribution charts
- Review personalized recommendations

### 3. Check History
- Navigate to the History tab
- View detailed analysis of each Reel
- Export your analysis data
- Filter by date or category

## Privacy & Security

### Data Protection
- **Encryption**: All sensitive data encrypted in transit and at rest
- **Ephemeral Processing**: Raw media files deleted immediately after analysis
- **Consent Management**: Explicit user consent required for data processing
- **Local Storage**: Minimal data stored locally with automatic cleanup

### Compliance
- **GDPR Compliant**: User data deletion on request
- **Privacy by Design**: Minimal data collection with purpose limitation
- **Transparency**: Clear audit logs and privacy status reporting

## API Documentation

### Classification Endpoint
```http
POST /api/classify
Content-Type: application/json

{
  "userId": "user123",
  "transcript": "Extracted text content",
  "overlayText": "OCR extracted text",
  "audioText": "ASR transcribed audio"
}
```

### Insights Endpoint
```http
GET /api/insights?userId=user123
```

### History Endpoint
```http
GET /api/history?userId=user123&limit=50
```

## Development

### Project Structure
```
lib/
├── bloc/           # BLoC state management
├── models/         # Data models
├── screens/        # UI screens
├── services/       # Business logic services
├── widgets/        # Reusable UI components
└── main.dart       # App entry point

android/app/src/main/kotlin/  # Android native services
backend/                      # Flask API server
```

### Key Components
- **ReelBloc**: Central state management for content analysis
- **AccessibilityService**: Android native monitoring service
- **ContentAnalyzer**: ML inference engine
- **SecurityService**: Encryption and privacy management
- **NotificationService**: Scheduled notifications and alerts

## Testing

### Unit Tests
```bash
flutter test
```

### Integration Tests
```bash
flutter drive --target=test_driver/app.dart
```

### Backend Tests
```bash
cd backend
python -m pytest
```

## Performance Optimization

### Memory Management
- Automatic cleanup of temporary files
- Efficient image processing with memory pooling
- Background service optimization

### Network Optimization
- Request batching for API calls
- Local caching of classification results
- Compression for data transmission

### Battery Optimization
- Adaptive polling frequency
- Background service throttling
- Resource usage monitoring

## Troubleshooting

### Common Issues
1. **Permissions Not Granted**: Check system settings for app permissions
2. **Service Not Starting**: Verify Accessibility Service is enabled
3. **Classification Failing**: Check network connection and API status
4. **High Battery Usage**: Adjust monitoring frequency in settings

### Debug Mode
Enable debug logging by setting:
```dart
import 'package:flutter/foundation.dart';
debugDefaultTargetPlatformOverride = TargetPlatform.fuchsia;
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Implement your changes with tests
4. Submit a pull request

## License

MIT License - see LICENSE file for details

## Support

For issues and support:
- Create an issue on GitHub
- Email: support@reel-ality-check.com
- Documentation: https://docs.reel-ality-check.com

## Version History

### v1.1.0 (Technical Revision)
- Enhanced ML models with improved accuracy
- Added comprehensive privacy features
- Implemented 72-hour clustering analysis
- Optimized performance for low-end devices

### v1.0.0 (Initial Release)
- Basic content classification
- Simple tilt index calculation
- Android monitoring service
- Flutter UI implementation

---

**Reel-ality Check** - Empowering users with insights into their algorithmic content consumption.
