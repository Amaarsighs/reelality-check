import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../models/reel_data.dart';
import '../services/api_service.dart';

part 'reel_event.dart';
part 'reel_state.dart';

class ReelBloc extends Bloc<ReelEvent, ReelState> {
  final ApiService _apiService = ApiService();

  ReelBloc() : super(const ReelState.initial()) {
    on<StartMonitoring>(_onStartMonitoring);
    on<StopMonitoring>(_onStopMonitoring);
    on<ReelDetected>(_onReelDetected);
    on<AnalyzeReel>(_onAnalyzeReel);
    on<LoadInsights>(_onLoadInsights);
    on<LoadHistory>(_onLoadHistory);
    on<UpdateTiltIndex>(_onUpdateTiltIndex);
  }

  Future<void> _onStartMonitoring(
    StartMonitoring event,
    Emitter<ReelState> emit,
  ) async {
    emit(state.copyWith(
      status: ReelStatus.monitoring,
      isMonitoring: true,
    ));
  }

  Future<void> _onStopMonitoring(
    StopMonitoring event,
    Emitter<ReelState> emit,
  ) async {
    emit(state.copyWith(
      status: ReelStatus.idle,
      isMonitoring: false,
    ));
  }

  Future<void> _onReelDetected(
    ReelDetected event,
    Emitter<ReelState> emit,
  ) async {
    emit(state.copyWith(
      status: ReelStatus.analyzing,
      currentReel: event.reelData,
    ));

    add(AnalyzeReel(event.reelData));
  }

  Future<void> _onAnalyzeReel(
    AnalyzeReel event,
    Emitter<ReelState> emit,
  ) async {
    try {
      final classification = await _apiService.classifyReel(event.reelData);
      
      final updatedReel = event.reelData.copyWith(
        classification: classification['label'],
        confidence: classification['confidence'],
        tiltScore: classification['tiltScore'],
      );

      final updatedHistory = List<ReelData>.from(state.reelHistory)
        ..add(updatedReel);

      emit(state.copyWith(
        status: ReelStatus.completed,
        reelHistory: updatedHistory,
        currentReel: updatedReel,
      ));

      add(LoadInsights());
    } catch (e) {
      emit(state.copyWith(
        status: ReelStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }

  Future<void> _onLoadInsights(
    LoadInsights event,
    Emitter<ReelState> emit,
  ) async {
    try {
      final insights = await _apiService.getInsights();
      
      emit(state.copyWith(
        insights: insights,
        tiltIndex: insights['tiltIndex'],
        dominantCluster: insights['dominantCluster'],
        clusters: insights['clusters'],
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ReelStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }

  Future<void> _onLoadHistory(
    LoadHistory event,
    Emitter<ReelState> emit,
  ) async {
    try {
      final history = await _apiService.getHistory();
      
      emit(state.copyWith(
        reelHistory: history.map((data) => ReelData.fromJson(data)).toList(),
      ));
    } catch (e) {
      emit(state.copyWith(
        status: ReelStatus.error,
        errorMessage: e.toString(),
      ));
    }
  }

  Future<void> _onUpdateTiltIndex(
    UpdateTiltIndex event,
    Emitter<ReelState> emit,
  ) async {
    emit(state.copyWith(
      tiltIndex: event.tiltIndex,
      lastUpdated: DateTime.now(),
    ));
  }
}
