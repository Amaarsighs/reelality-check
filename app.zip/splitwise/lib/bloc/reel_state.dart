part of 'reel_bloc.dart';

enum ReelStatus { idle, monitoring, analyzing, completed, error }

class ReelState extends Equatable {
  final ReelStatus status;
  final bool isMonitoring;
  final ReelData? currentReel;
  final List<ReelData> reelHistory;
  final Map<String, dynamic> insights;
  final double tiltIndex;
  final String? dominantCluster;
  final Map<String, dynamic> clusters;
  final String? errorMessage;
  final DateTime? lastUpdated;

  const ReelState({
    this.status = ReelStatus.idle,
    this.isMonitoring = false,
    this.currentReel,
    this.reelHistory = const [],
    this.insights = const {},
    this.tiltIndex = 0.0,
    this.dominantCluster,
    this.clusters = const {},
    this.errorMessage,
    this.lastUpdated,
  });

  ReelState copyWith({
    ReelStatus? status,
    bool? isMonitoring,
    ReelData? currentReel,
    List<ReelData>? reelHistory,
    Map<String, dynamic>? insights,
    double? tiltIndex,
    String? dominantCluster,
    Map<String, dynamic>? clusters,
    String? errorMessage,
    DateTime? lastUpdated,
  }) {
    return ReelState(
      status: status ?? this.status,
      isMonitoring: isMonitoring ?? this.isMonitoring,
      currentReel: currentReel ?? this.currentReel,
      reelHistory: reelHistory ?? this.reelHistory,
      insights: insights ?? this.insights,
      tiltIndex: tiltIndex ?? this.tiltIndex,
      dominantCluster: dominantCluster ?? this.dominantCluster,
      clusters: clusters ?? this.clusters,
      errorMessage: errorMessage ?? this.errorMessage,
      lastUpdated: lastUpdated ?? this.lastUpdated,
    );
  }

  @override
  List<Object> get props => [
        status,
        isMonitoring,
        currentReel,
        reelHistory,
        insights,
        tiltIndex,
        dominantCluster,
        clusters,
        errorMessage,
        lastUpdated,
      ];

  const ReelState.initial()
      : status = ReelStatus.idle,
        isMonitoring = false,
        currentReel = null,
        reelHistory = const [],
        insights = const {},
        tiltIndex = 0.0,
        dominantCluster = null,
        clusters = const {},
        errorMessage = null,
        lastUpdated = null;
}
