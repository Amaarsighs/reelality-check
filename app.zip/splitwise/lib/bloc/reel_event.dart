part of 'reel_bloc.dart';

abstract class ReelEvent extends Equatable {
  const ReelEvent();

  @override
  List<Object> get props => [];
}

class StartMonitoring extends ReelEvent {}

class StopMonitoring extends ReelEvent {}

class ReelDetected extends ReelEvent {
  final ReelData reelData;

  const ReelDetected(this.reelData);

  @override
  List<Object> get props => [reelData];
}

class AnalyzeReel extends ReelEvent {
  final ReelData reelData;

  const AnalyzeReel(this.reelData);

  @override
  List<Object> get props => [reelData];
}

class LoadInsights extends ReelEvent {}

class LoadHistory extends ReelEvent {}

class UpdateTiltIndex extends ReelEvent {
  final double tiltIndex;

  const UpdateTiltIndex(this.tiltIndex);

  @override
  List<Object> get props => [tiltIndex];
}
