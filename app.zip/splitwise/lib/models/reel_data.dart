import 'package:equatable/equatable.dart';

class ReelData extends Equatable {
  final String id;
  final DateTime timestamp;
  final String transcript;
  final String overlayText;
  final String audioText;
  final String? classification;
  final double? confidence;
  final double? tiltScore;
  final Map<String, dynamic> features;

  const ReelData({
    required this.id,
    required this.timestamp,
    required this.transcript,
    required this.overlayText,
    required this.audioText,
    this.classification,
    this.confidence,
    this.tiltScore,
    this.features = const {},
  });

  ReelData copyWith({
    String? id,
    DateTime? timestamp,
    String? transcript,
    String? overlayText,
    String? audioText,
    String? classification,
    double? confidence,
    double? tiltScore,
    Map<String, dynamic>? features,
  }) {
    return ReelData(
      id: id ?? this.id,
      timestamp: timestamp ?? this.timestamp,
      transcript: transcript ?? this.transcript,
      overlayText: overlayText ?? this.overlayText,
      audioText: audioText ?? this.audioText,
      classification: classification ?? this.classification,
      confidence: confidence ?? this.confidence,
      tiltScore: tiltScore ?? this.tiltScore,
      features: features ?? this.features,
    );
  }

  factory ReelData.fromJson(Map<String, dynamic> json) {
    return ReelData(
      id: json['id'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      transcript: json['transcript'] as String,
      overlayText: json['overlayText'] as String,
      audioText: json['audioText'] as String,
      classification: json['classification'] as String?,
      confidence: (json['confidence'] as num?)?.toDouble(),
      tiltScore: (json['tiltScore'] as num?)?.toDouble(),
      features: json['features'] as Map<String, dynamic>? ?? {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'transcript': transcript,
      'overlayText': overlayText,
      'audioText': audioText,
      'classification': classification,
      'confidence': confidence,
      'tiltScore': tiltScore,
      'features': features,
    };
  }

  @override
  List<Object?> get props => [
        id,
        timestamp,
        transcript,
        overlayText,
        audioText,
        classification,
        confidence,
        tiltScore,
        features,
      ];
}
