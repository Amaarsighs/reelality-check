import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'bloc/reel_bloc.dart';
import 'bloc/reel_event.dart';
import 'bloc/reel_state.dart';
import 'screens/home_screen.dart';
import 'screens/insights_screen.dart';
import 'screens/history_screen.dart';
import 'services/background_service.dart';
import 'services/notification_service.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  await initializeService();
  await NotificationService.initialize(flutterLocalNotificationsPlugin);
  
  runApp(const ReelRealityCheckApp());
}

class ReelRealityCheckApp extends StatelessWidget {
  const ReelRealityCheckApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reel-ality Check',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        scaffoldBackgroundColor: const Color(0xFFF5F5F5),
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _currentIndex = 0;
  late ReelBloc _reelBloc;

  final List<Widget> _screens = [
    const HomeScreen(),
    const InsightsScreen(),
    const HistoryScreen(),
  ];

  @override
  void initState() {
    super.initState();
    _reelBloc = ReelBloc();
    _requestPermissions();
  }

  Future<void> _requestPermissions() async {
    await [
      Permission.systemAlertWindow,
      Permission.accessibilityService,
      Permission.storage,
      Permission.microphone,
      Permission.notification,
    ].request();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _reelBloc,
      child: Scaffold(
        body: IndexedStack(
          index: _currentIndex,
          children: _screens,
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Monitor',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.analytics),
              label: 'Insights',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.history),
              label: 'History',
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _reelBloc.close();
    super.dispose();
  }
}
