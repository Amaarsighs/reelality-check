import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../bloc/reel_bloc.dart';
import '../bloc/reel_state.dart';
import '../widgets/tilt_indicator.dart';
import '../widgets/cluster_chart.dart';
import '../widgets/category_breakdown.dart';

class InsightsScreen extends StatelessWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Content Insights'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () => _refreshInsights(context),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: BlocBuilder<ReelBloc, ReelState>(
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTiltIndexCard(context, state),
                const SizedBox(height: 20),
                _buildClusterAnalysis(context, state),
                const SizedBox(height: 20),
                _buildCategoryDistribution(context, state),
                const SizedBox(height: 20),
                _buildRecommendations(context, state),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildTiltIndexCard(BuildContext context, ReelState state) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Content Tilt Index',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: _getTiltColor(state.tiltIndex),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    _getTiltLevel(state.tiltIndex),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            TiltIndicator(
              tiltIndex: state.tiltIndex,
              size: 200,
            ),
            const SizedBox(height: 16),
            _buildTiltDescription(state.tiltIndex),
          ],
        ),
      ),
    );
  }

  Widget _buildTiltDescription(double tiltIndex) {
    String description;
    Color color;
    
    if (tiltIndex < 20) {
      description = 'Your content consumption is well-balanced across different categories. Keep maintaining this diverse media diet!';
      color = Colors.green;
    } else if (tiltIndex < 40) {
      description = 'You show a slight preference toward certain content types. Consider exploring more diverse categories for a balanced perspective.';
      color = Colors.orange;
    } else {
      description = 'Your content consumption shows significant bias toward specific categories. This may indicate algorithmic filter bubbles affecting your media exposure.';
      color = Colors.red;
    }
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline,
            color: color,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              description,
              style: TextStyle(
                color: color,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildClusterAnalysis(BuildContext context, ReelState state) {
    if (state.clusters.isEmpty) {
      return Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: const Padding(
          padding: EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.analytics_outlined,
                  size: 48,
                  color: Colors.grey,
                ),
                SizedBox(height: 8),
                Text(
                  'Insufficient data for clustering',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
                Text(
                  'Continue monitoring to see patterns',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Content Clustering Analysis',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ClusterChart(
              clusters: state.clusters,
              dominantCluster: state.dominantCluster,
            ),
            const SizedBox(height: 16),
            _buildClusterInfo(state),
          ],
        ),
      ),
    );
  }

  Widget _buildClusterInfo(ReelState state) {
    if (state.dominantCluster == null) return const SizedBox.shrink();
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Dominant Cluster: ${state.dominantCluster}',
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        if (state.clusters['cluster_weights'] != null)
          ...state.clusters['cluster_weights'].entries.map((entry) {
            final clusterId = entry.key;
            final weight = (entry.value as num).toDouble();
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 2.0),
              child: Row(
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      color: _getClusterColor(int.parse(clusterId)),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text('Cluster $clusterId'),
                  const Spacer(),
                  Text(
                    '${(weight * 100).toStringAsFixed(1)}%',
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            );
          }).toList(),
      ],
    );
  }

  Widget _buildCategoryDistribution(BuildContext context, ReelState state) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Category Distribution',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            CategoryBreakdown(reelHistory: state.reelHistory),
          ],
        ),
      ),
    );
  }

  Widget _buildRecommendations(BuildContext context, ReelState state) {
    final recommendations = _generateRecommendations(state);
    
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Personalized Recommendations',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            ...recommendations.map((recommendation) => Padding(
              padding: const EdgeInsets.only(bottom: 12.0),
              child: RecommendationCard(recommendation: recommendation),
            )),
          ],
        ),
      ),
    );
  }

  List<Recommendation> _generateRecommendations(ReelState state) {
    final recommendations = <Recommendation>[];
    
    if (state.tiltIndex > 40) {
      recommendations.add(Recommendation(
        title: 'Diversify Your Content',
        description: 'Try following accounts in different categories to balance your feed',
        icon: Icons.diversity_3,
        priority: Priority.high,
      ));
    }
    
    if (state.reelHistory.length < 10) {
      recommendations.add(Recommendation(
        title: 'Continue Monitoring',
        description: 'We need more data to provide accurate insights',
        icon: Icons.monitor_heart,
        priority: Priority.medium,
      ));
    }
    
    if (state.dominantCluster != null) {
      recommendations.add(Recommendation(
        title: 'Explore New Topics',
        description: 'Your content is heavily focused in one area - try exploring new interests',
        icon: Icons.explore,
        priority: Priority.low,
      ));
    }
    
    return recommendations;
  }

  void _refreshInsights(BuildContext context) {
    context.read<ReelBloc>().add(LoadInsights());
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Refreshing insights...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  Color _getTiltColor(double tiltIndex) {
    if (tiltIndex < 20) return Colors.green;
    if (tiltIndex < 40) return Colors.orange;
    return Colors.red;
  }

  String _getTiltLevel(double tiltIndex) {
    if (tiltIndex < 20) return 'BALANCED';
    if (tiltIndex < 40) return 'SLIGHT TILT';
    return 'HIGH TILT';
  }

  Color _getClusterColor(int clusterId) {
    final colors = [
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.red,
    ];
    return colors[clusterId % colors.length];
  }
}

class Recommendation {
  final String title;
  final String description;
  final IconData icon;
  final Priority priority;

  Recommendation({
    required this.title,
    required this.description,
    required this.icon,
    required this.priority,
  });
}

enum Priority { high, medium, low }

class RecommendationCard extends StatelessWidget {
  final Recommendation recommendation;

  const RecommendationCard({
    super.key,
    required this.recommendation,
  });

  @override
  Widget build(BuildContext context) {
    Color priorityColor;
    String priorityText;
    
    switch (recommendation.priority) {
      case Priority.high:
        priorityColor = Colors.red;
        priorityText = 'High';
        break;
      case Priority.medium:
        priorityColor = Colors.orange;
        priorityText = 'Medium';
        break;
      case Priority.low:
        priorityColor = Colors.green;
        priorityText = 'Low';
        break;
    }
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: priorityColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(
              recommendation.icon,
              color: priorityColor,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        recommendation.title,
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 2,
                      ),
                      decoration: BoxDecoration(
                        color: priorityColor,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        priorityText,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  recommendation.description,
                  style: TextStyle(
                    color: Colors.grey[600],
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
