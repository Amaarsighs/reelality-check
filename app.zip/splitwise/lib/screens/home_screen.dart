import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/reel_bloc.dart';
import '../bloc/reel_state.dart';
import '../services/permission_service.dart';
import '../widgets/monitoring_card.dart';
import '../widgets/status_indicator.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reel-ality Check'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: BlocBuilder<ReelBloc, ReelState>(
        builder: (context, state) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildStatusCard(context, state),
                const SizedBox(height: 20),
                _buildMonitoringControls(context, state),
                const SizedBox(height: 20),
                _buildCurrentAnalysis(context, state),
                const SizedBox(height: 20),
                _buildPermissionsCard(context),
                const SizedBox(height: 20),
                _buildSystemInfo(context),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusCard(BuildContext context, ReelState state) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'System Status',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                StatusIndicator(
                  isActive: state.isMonitoring,
                  status: state.status,
                ),
              ],
            ),
            const SizedBox(height: 12),
            _buildStatusInfo(state),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusInfo(ReelState state) {
    String statusText = '';
    Color statusColor = Colors.grey;
    
    switch (state.status) {
      case ReelStatus.idle:
        statusText = 'Ready to monitor';
        statusColor = Colors.grey;
        break;
      case ReelStatus.monitoring:
        statusText = 'Monitoring Instagram Reels';
        statusColor = Colors.green;
        break;
      case ReelStatus.analyzing:
        statusText = 'Analyzing content...';
        statusColor = Colors.orange;
        break;
      case ReelStatus.completed:
        statusText = 'Analysis complete';
        statusColor = Colors.blue;
        break;
      case ReelStatus.error:
        statusText = 'Error occurred';
        statusColor = Colors.red;
        break;
    }
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              Icons.info_outline,
              color: statusColor,
              size: 16,
            ),
            const SizedBox(width: 8),
            Text(
              statusText,
              style: TextStyle(
                color: statusColor,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        if (state.errorMessage != null) ...[
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.red[50],
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.error_outline,
                  color: Colors.red[700],
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    state.errorMessage!,
                    style: TextStyle(
                      color: Colors.red[700],
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildMonitoringControls(BuildContext context, ReelState state) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Monitoring Controls',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: state.isMonitoring
                        ? null
                        : () => _startMonitoring(context),
                    icon: const Icon(Icons.play_arrow),
                    label: const Text('Start Monitoring'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: state.isMonitoring
                        ? () => _stopMonitoring(context)
                        : null,
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop Monitoring'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              'Monitoring: ${state.isMonitoring ? "Active" : "Inactive"}',
              style: TextStyle(
                color: state.isMonitoring ? Colors.green : Colors.grey,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentAnalysis(BuildContext context, ReelState state) {
    if (state.currentReel == null) {
      return Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        child: const Padding(
          padding: EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              children: [
                Icon(
                  Icons.video_library_outlined,
                  size: 48,
                  color: Colors.grey,
                ),
                SizedBox(height: 8),
                Text(
                  'No content analyzed yet',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 16,
                  ),
                ),
                Text(
                  'Start monitoring to begin analysis',
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return MonitoringCard(reelData: state.currentReel!);
  }

  Widget _buildPermissionsCard(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Required Permissions',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<bool>>(
              future: _checkPermissions(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const CircularProgressIndicator();
                }

                final permissions = snapshot.data!;
                final permissionNames = [
                  'Accessibility Service',
                  'Screen Capture',
                  'Storage Access',
                  'Microphone',
                ];

                return Column(
                  children: List.generate(
                    permissionNames.length,
                    (index) => PermissionRow(
                      name: permissionNames[index],
                      granted: permissions[index],
                      onGrant: () => _requestPermission(context, index),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSystemInfo(BuildContext context) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'System Information',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            BlocBuilder<ReelBloc, ReelState>(
              builder: (context, state) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InfoRow(
                      label: 'Total Analyzed',
                      value: '${state.reelHistory.length}',
                    ),
                    InfoRow(
                      label: 'Current Tilt Index',
                      value: state.tiltIndex.toStringAsFixed(2),
                    ),
                    InfoRow(
                      label: 'Last Updated',
                      value: state.lastUpdated != null
                          ? _formatDateTime(state.lastUpdated!)
                          : 'Never',
                    ),
                    if (state.dominantCluster != null)
                      InfoRow(
                        label: 'Dominant Cluster',
                        value: 'Cluster ${state.dominantCluster}',
                      ),
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  void _startMonitoring(BuildContext context) {
    context.read<ReelBloc>().add(StartMonitoring());
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Monitoring started'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _stopMonitoring(BuildContext context) {
    context.read<ReelBloc>().add(StopMonitoring());
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Monitoring stopped'),
        backgroundColor: Colors.red,
      ),
    );
  }

  Future<List<bool>> _checkPermissions() async {
    return await PermissionService.checkAllPermissions();
  }

  void _requestPermission(BuildContext context, int index) async {
    await PermissionService.requestPermission(index);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Permission requested - please check system settings'),
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return '${dateTime.hour.toString().padLeft(2, '0')}:'
           '${dateTime.minute.toString().padLeft(2, '0')}';
  }
}

class PermissionRow extends StatelessWidget {
  final String name;
  final bool granted;
  final VoidCallback onGrant;

  const PermissionRow({
    super.key,
    required this.name,
    required this.granted,
    required this.onGrant,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        children: [
          Icon(
            granted ? Icons.check_circle : Icons.error_outline,
            color: granted ? Colors.green : Colors.orange,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                color: granted ? Colors.black87 : Colors.black54,
                fontWeight: granted ? FontWeight.normal : FontWeight.w500,
              ),
            ),
          ),
          if (!granted)
            TextButton(
              onPressed: onGrant,
              child: const Text('Grant'),
            ),
        ],
      ),
    );
  }
}

class InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const InfoRow({
    super.key,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: Colors.grey,
              fontSize: 14,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}
