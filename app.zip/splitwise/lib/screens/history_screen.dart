import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../bloc/reel_bloc.dart';
import '../bloc/reel_state.dart';
import '../models/reel_data.dart';
import '../widgets/history_item.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analysis History'),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: () => _showFilterDialog(context),
            icon: const Icon(Icons.filter_list),
          ),
          IconButton(
            onPressed: () => _exportHistory(context),
            icon: const Icon(Icons.download),
          ),
        ],
      ),
      body: BlocBuilder<ReelBloc, ReelState>(
        builder: (context, state) {
          final history = state.reelHistory;
          
          if (history.isEmpty) {
            return _buildEmptyState();
          }
          
          return Column(
            children: [
              _buildStatsHeader(state),
              Expanded(
                child: _buildHistoryList(history),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history_outlined,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No Analysis History',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start monitoring Instagram Reels to see your content analysis history',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              // Navigate to home screen to start monitoring
            },
            icon: const Icon(Icons.play_arrow),
            label: const Text('Start Monitoring'),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[600],
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsHeader(ReelState state) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        border: Border(
          bottom: BorderSide(color: Colors.blue[200]!),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Analysis Statistics',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.blue[800],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _buildStatItem(
                  'Total Analyzed',
                  '${state.reelHistory.length}',
                  Icons.analytics,
                  Colors.blue,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  'Avg Tilt Score',
                  _calculateAverageTilt(state.reelHistory),
                  Icons.trending_up,
                  Colors.orange,
                ),
              ),
              Expanded(
                child: _buildStatItem(
                  'Top Category',
                  _getTopCategory(state.reelHistory),
                  Icons.category,
                  Colors.green,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, IconData icon, Color color) {
    return Column(
      children: [
        Icon(
          icon,
          color: color,
          size: 24,
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  Widget _buildHistoryList(List<ReelData> history) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: history.length,
      itemBuilder: (context, index) {
        final reelData = history[history.length - 1 - index]; // Reverse order
        return HistoryItem(
          reelData: reelData,
          onTap: () => _showReelDetails(context, reelData),
        );
      },
    );
  }

  void _showReelDetails(BuildContext context, ReelData reelData) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => ReelDetailsSheet(reelData: reelData),
    );
  }

  void _showFilterDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Filter History'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Filter options coming soon...'),
            // TODO: Implement filter options
            // - Date range
            // - Category filter
            // - Tilt score range
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  void _exportHistory(BuildContext context) {
    // TODO: Implement export functionality
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export feature coming soon...'),
      ),
    );
  }

  String _calculateAverageTilt(List<ReelData> history) {
    if (history.isEmpty) return '0.0';
    
    final tiltScores = history
        .where((reel) => reel.tiltScore != null)
        .map((reel) => reel.tiltScore!)
        .toList();
    
    if (tiltScores.isEmpty) return 'N/A';
    
    final average = tiltScores.reduce((a, b) => a + b) / tiltScores.length;
    return average.toStringAsFixed(2);
  }

  String _getTopCategory(List<ReelData> history) {
    if (history.isEmpty) return 'N/A';
    
    final categories = history
        .where((reel) => reel.classification != null)
        .map((reel) => reel.classification!)
        .toList();
    
    if (categories.isEmpty) return 'N/A';
    
    final categoryCounts = <String, int>{};
    for (final category in categories) {
      categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
    }
    
    final topCategory = categoryCounts.entries
        .reduce((a, b) => a.value > b.value ? a : b)
        .key;
    
    return topCategory;
  }
}

class ReelDetailsSheet extends StatelessWidget {
  final ReelData reelData;

  const ReelDetailsSheet({
    super.key,
    required this.reelData,
  });

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.9,
      builder: (context, scrollController) {
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: const BoxDecoration(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            color: Colors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Reel Analysis Details',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDetailSection(
                        'Timestamp',
                        DateFormat('MMM dd, yyyy • hh:mm a').format(reelData.timestamp),
                        Icons.schedule,
                      ),
                      const SizedBox(height: 16),
                      _buildDetailSection(
                        'Classification',
                        reelData.classification ?? 'Not classified',
                        Icons.category,
                        color: _getCategoryColor(reelData.classification),
                      ),
                      if (reelData.confidence != null) ...[
                        const SizedBox(height: 8),
                        Text(
                          'Confidence: ${(reelData.confidence! * 100).toStringAsFixed(1)}%',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 12,
                          ),
                        ),
                      ],
                      const SizedBox(height: 16),
                      _buildDetailSection(
                        'Tilt Score',
                        reelData.tiltScore?.toStringAsFixed(3) ?? 'N/A',
                        Icons.trending_up,
                        color: _getTiltColor(reelData.tiltScore),
                      ),
                      const SizedBox(height: 16),
                      _buildDetailSection(
                        'Transcript',
                        reelData.transcript.isNotEmpty 
                            ? reelData.transcript 
                            : 'No transcript available',
                        Icons.transcribe,
                      ),
                      const SizedBox(height: 16),
                      _buildDetailSection(
                        'Overlay Text',
                        reelData.overlayText.isNotEmpty
                            ? reelData.overlayText
                            : 'No overlay text detected',
                        Icons.text_fields,
                      ),
                      const SizedBox(height: 16),
                      _buildDetailSection(
                        'Audio Text',
                        reelData.audioText.isNotEmpty
                            ? reelData.audioText
                            : 'No audio text detected',
                        Icons.mic,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDetailSection(String title, String content, IconData icon, {Color? color}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(
              icon,
              size: 16,
              color: color ?? Colors.grey[600],
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Colors.grey[700],
                fontSize: 14,
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.grey[50],
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[200]!),
          ),
          child: Text(
            content,
            style: TextStyle(
              color: Colors.grey[800],
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }

  Color _getCategoryColor(String? category) {
    if (category == null) return Colors.grey;
    
    final categoryColors = {
      'Entertainment': Colors.purple,
      'Educational': Colors.blue,
      'News_Politics': Colors.red,
      'Lifestyle': Colors.green,
      'Sports': Colors.orange,
      'Technology': Colors.indigo,
      'Fashion': Colors.pink,
      'Food': Colors.brown,
      'Travel': Colors.teal,
      'Health_Fitness': Colors.green,
    };
    
    return categoryColors[category] ?? Colors.grey;
  }

  Color _getTiltColor(double? tiltScore) {
    if (tiltScore == null) return Colors.grey;
    
    if (tiltScore.abs() < 0.2) return Colors.green;
    if (tiltScore.abs() < 0.4) return Colors.orange;
    return Colors.red;
  }
}
