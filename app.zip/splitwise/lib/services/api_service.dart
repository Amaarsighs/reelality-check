import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/reel_data.dart';
import 'security_service.dart';

class ApiService {
  static const String _baseUrl = 'https://your-backend-domain.com/api'; // Replace with actual backend URL
  static const Duration _timeout = Duration(seconds: 8); // NFR-2: RTT < 8.0 seconds
  
  static Future<Map<String, dynamic>> classifyReel(ReelData reelData) async {
    try {
      // Check privacy consent before processing
      final hasConsent = await SecurityService.hasPrivacyConsent();
      if (!hasConsent) {
        throw Exception('Privacy consent required for content analysis');
      }
      
      // Prepare request data with encryption
      final requestData = {
        'userId': 'anonymous', // In production, get actual user ID
        'transcript': SecurityService.sanitizeInput(reelData.transcript),
        'overlayText': SecurityService.sanitizeInput(reelData.overlayText),
        'audioText': SecurityService.sanitizeInput(reelData.audioText),
        'timestamp': reelData.timestamp.toIso8601String(),
      };
      
      // Encrypt sensitive data
      final encryptedData = SecurityService.encryptData(jsonEncode(requestData));
      
      // Make secure API call
      final response = await http.post(
        Uri.parse('$_baseUrl/classify'),
        headers: {
          ...SecurityService.getSecureHeaders(),
          'Content-Type': 'application/json',
          'X-Encrypted-Data': 'true',
        },
        body: jsonEncode({'encrypted_data': encryptedData}),
      ).timeout(_timeout);
      
      if (response.statusCode == 200) {
        // Decrypt response
        final responseData = jsonDecode(response.body);
        final decryptedResponse = SecurityService.decryptData(responseData['encrypted_result']);
        
        final result = jsonDecode(decryptedResponse);
        
        // Log security event
        await SecurityService.logSecurityEvent('content_classified', {
          'success': true,
          'classification': result['classification']['label'],
        });
        
        return result;
      } else {
        throw Exception('API Error: ${response.statusCode}');
      }
    } catch (e) {
      // Log security event
      await SecurityService.logSecurityEvent('content_classification_failed', {
        'error': e.toString(),
      });
      
      rethrow;
    }
  }
  
  static Future<Map<String, dynamic>> getInsights() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/insights?userId=anonymous'),
        headers: SecurityService.getSecureHeaders(),
      ).timeout(_timeout);
      
      if (response.statusCode == 200) {
        final insights = jsonDecode(response.body);
        
        // Update local tilt index for background service
        await BackgroundServiceController.updateTiltIndex(
          insights['tiltIndex']?.toDouble() ?? 0.0,
        );
        
        if (insights['dominantCluster'] != null) {
          await BackgroundServiceController.updateDominantCluster(
            insights['dominantCluster'].toString(),
          );
        }
        
        return insights;
      } else {
        throw Exception('Failed to fetch insights: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Insights fetch failed: $e');
    }
  }
  
  static Future<List<Map<String, dynamic>>> getHistory() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/history?userId=anonymous&limit=50'),
        headers: SecurityService.getSecureHeaders(),
      ).timeout(_timeout);
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['history']);
      } else {
        throw Exception('Failed to fetch history: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('History fetch failed: $e');
    }
  }
  
  static Future<Map<String, dynamic>> extractTextFromImage(String base64Image) async {
    try {
      final requestData = {
        'image': base64Image,
        'timestamp': DateTime.now().toIso8601String(),
      };
      
      final response = await http.post(
        Uri.parse('$_baseUrl/extract_text'),
        headers: {
          ...SecurityService.getSecureHeaders(),
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestData),
      ).timeout(_timeout);
      
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('OCR failed: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Text extraction failed: $e');
    }
  }
  
  static Future<Map<String, dynamic>> extractTextFromAudio(String audioFilePath) async {
    try {
      // In a real implementation, this would upload the audio file
      // For now, we'll simulate the ASR process
      
      final requestData = {
        'audio_path': audioFilePath,
        'timestamp': DateTime.now().toIso8601String(),
      };
      
      final response = await http.post(
        Uri.parse('$_baseUrl/extract_text'),
        headers: {
          ...SecurityService.getSecureHeaders(),
          'Content-Type': 'application/json',
        },
        body: jsonEncode(requestData),
      ).timeout(_timeout);
      
      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception('ASR failed: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Audio transcription failed: $e');
    }
  }
  
  static Future<bool> testConnection() async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/health'),
        headers: SecurityService.getSecureHeaders(),
      ).timeout(const Duration(seconds: 5));
      
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }
  
  static Future<void> reportError(String error, Map<String, dynamic> context) async {
    try {
      final errorReport = {
        'error': error,
        'context': context,
        'timestamp': DateTime.now().toIso8601String(),
        'user_id': 'anonymous',
        'app_version': '1.1.0',
      };
      
      await http.post(
        Uri.parse('$_baseUrl/error_report'),
        headers: {
          ...SecurityService.getSecureHeaders(),
          'Content-Type': 'application/json',
        },
        body: jsonEncode(errorReport),
      ).timeout(const Duration(seconds: 5));
    } catch (e) {
      // Silent fail for error reporting
      print('Failed to report error: $e');
    }
  }
  
  // Performance monitoring for NFR-2 compliance
  static Future<Map<String, dynamic>> getPerformanceMetrics() async {
    try {
      final startTime = DateTime.now();
      
      // Test API response time
      await testConnection();
      
      final endTime = DateTime.now();
      final responseTime = endTime.difference(startTime).inMilliseconds;
      
      return {
        'api_response_time_ms': responseTime,
        'within_sla': responseTime < _timeout.inMilliseconds,
        'timestamp': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {
        'error': e.toString(),
        'within_sla': false,
        'timestamp': DateTime.now().toIso8601String(),
      };
    }
  }
}

// Import BackgroundServiceController
import 'background_service.dart';
