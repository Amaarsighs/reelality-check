import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

class SecurityService {
  static const String _encryptionKeyKey = 'encryption_key';
  static const String _saltKey = 'encryption_salt';
  
  // Privacy-by-Design: Ephemeral Data Processing (NFR-1)
  static const Duration _dataRetentionPeriod = Duration(hours: 24);
  static const int _maxRetainedFiles = 50;
  
  static late String _encryptionKey;
  static late String _salt;
  
  static Future<void> initialize() async {
    await _initializeEncryption();
    await _setupPrivacyPolicies();
  }
  
  static Future<void> _initializeEncryption() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Check if we already have encryption keys
    String? storedKey = prefs.getString(_encryptionKeyKey);
    String? storedSalt = prefs.getString(_saltKey);
    
    if (storedKey != null && storedSalt != null) {
      _encryptionKey = storedKey;
      _salt = storedSalt;
    } else {
      // Generate new encryption keys
      final key = _generateSecureKey();
      final salt = _generateSalt();
      
      _encryptionKey = key;
      _salt = salt;
      
      // Store keys securely
      await prefs.setString(_encryptionKeyKey, key);
      await prefs.setString(_saltKey, salt);
    }
  }
  
  static String _generateSecureKey() {
    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    return base64.encode(bytes);
  }
  
  static String _generateSalt() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    return base64.encode(bytes);
  }
  
  // Data encryption for API transmissions (NFR-4)
  static String encryptData(String data) {
    try {
      final keyBytes = base64.decode(_encryptionKey);
      final saltBytes = base64.decode(_salt);
      
      // Simple XOR encryption for demonstration
      // In production, use proper AES encryption
      final dataBytes = utf8.encode(data);
      final encryptedBytes = <int>[];
      
      for (int i = 0; i < dataBytes.length; i++) {
        encryptedBytes.add(dataBytes[i] ^ keyBytes[i % keyBytes.length] ^ saltBytes[i % saltBytes.length]);
      }
      
      return base64.encode(encryptedBytes);
    } catch (e) {
      throw SecurityException('Encryption failed: $e');
    }
  }
  
  static String decryptData(String encryptedData) {
    try {
      final keyBytes = base64.decode(_encryptionKey);
      final saltBytes = base64.decode(_salt);
      final encryptedBytes = base64.decode(encryptedData);
      
      final decryptedBytes = <int>[];
      
      for (int i = 0; i < encryptedBytes.length; i++) {
        decryptedBytes.add(encryptedBytes[i] ^ keyBytes[i % keyBytes.length] ^ saltBytes[i % saltBytes.length]);
      }
      
      return utf8.decode(decryptedBytes);
    } catch (e) {
      throw SecurityException('Decryption failed: $e');
    }
  }
  
  // Hash sensitive data for storage
  static String hashData(String data) {
    final bytes = utf8.encode(data + _salt);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }
  
  // Ephemeral Data Processing (NFR-1)
  static Future<void> processEphemeralData(String filePath) async {
    try {
      final file = File(filePath);
      
      if (await file.exists()) {
        // Process the data immediately
        // This would integrate with OCR/ASR processing
        
        // Schedule for deletion after processing
        _scheduleDataDeletion(file);
      }
    } catch (e) {
      throw SecurityException('Failed to process ephemeral data: $e');
    }
  }
  
  static void _scheduleDataDeletion(File file) {
    // Schedule deletion after retention period
    Future.delayed(_dataRetentionPeriod, () async {
      try {
        if (await file.exists()) {
          await file.delete();
          print('Ephemeral data deleted: ${file.path}');
        }
      } catch (e) {
        print('Failed to delete ephemeral data: $e');
      }
    });
  }
  
  // Cleanup old temporary files
  static Future<void> cleanupTempFiles() async {
    try {
      final tempDir = await getTemporaryDirectory();
      final files = await tempDir.list().toList();
      
      int deletedCount = 0;
      
      for (final file in files) {
        if (file is File) {
          final stat = await file.stat();
          final age = DateTime.now().difference(stat.modified);
          
          if (age > _dataRetentionPeriod) {
            await file.delete();
            deletedCount++;
          }
        }
      }
      
      // Also enforce maximum file limit
      if (deletedCount < _maxRetainedFiles) {
        await _enforceFileLimit(tempDir);
      }
      
      print('Cleaned up $deletedCount temporary files');
    } catch (e) {
      print('Error during temp file cleanup: $e');
    }
  }
  
  static Future<void> _enforceFileLimit(Directory tempDir) async {
    try {
      final files = await tempDir.list().whereType<File>().toList();
      
      if (files.length > _maxRetainedFiles) {
        // Sort by modification time (oldest first)
        files.sort((a, b) async {
          final statA = await a.stat();
          final statB = await b.stat();
          return statA.modified.compareTo(statB.modified);
        });
        
        // Delete oldest files
        final filesToDelete = files.take(files.length - _maxRetainedFiles);
        
        for (final file in filesToDelete) {
          await file.delete();
        }
      }
    } catch (e) {
      print('Error enforcing file limit: $e');
    }
  }
  
  // Privacy consent management
  static Future<void> recordPrivacyConsent(bool consent) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('privacy_consent', consent);
      await prefs.setString('consent_timestamp', DateTime.now().toIso8601String());
      
      if (!consent) {
        // If consent is withdrawn, delete all stored data
        await _deleteAllUserData();
      }
    } catch (e) {
      throw SecurityException('Failed to record privacy consent: $e');
    }
  }
  
  static Future<bool> hasPrivacyConsent() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool('privacy_consent') ?? false;
    } catch (e) {
      return false;
    }
  }
  
  static Future<void> _deleteAllUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      
      // Delete all temporary files
      await cleanupTempFiles();
      
      // Reset encryption keys
      await _initializeEncryption();
    } catch (e) {
      print('Error deleting user data: $e');
    }
  }
  
  // API Security (NFR-4)
  static Map<String, String> getSecureHeaders() {
    return {
      'Content-Type': 'application/json',
      'X-Api-Version': '1.1',
      'X-Client-Timestamp': DateTime.now().toIso8601String(),
      'X-Request-ID': _generateRequestId(),
    };
  }
  
  static String _generateRequestId() {
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final random = Random.secure();
    final randomBytes = List<int>.generate(8, (_) => random.nextInt(256));
    return '$timestamp-${base64.encode(randomBytes)}';
  }
  
  // Data validation and sanitization
  static String sanitizeInput(String input) {
    // Remove potentially harmful characters
    return input
        .replaceAll(RegExp(r'[<>"\']'), '')
        .trim()
        .substring(0, min(1000, input.length)); // Limit length
  }
  
  static bool isValidEmail(String email) {
    return RegExp(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$').hasMatch(email);
  }
  
  // Audit logging
  static Future<void> logSecurityEvent(String event, Map<String, dynamic> context) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final logs = prefs.getStringList('security_logs') ?? [];
      
      final logEntry = {
        'timestamp': DateTime.now().toIso8601String(),
        'event': event,
        'context': context,
        'user_id': 'anonymous', // In production, get actual user ID
      };
      
      logs.add(jsonEncode(logEntry));
      
      // Keep only last 1000 logs
      if (logs.length > 1000) {
        logs.removeRange(0, logs.length - 1000);
      }
      
      await prefs.setStringList('security_logs', logs);
    } catch (e) {
      print('Failed to log security event: $e');
    }
  }
  
  // Privacy compliance checks
  static Future<Map<String, dynamic>> getPrivacyStatus() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      
      return {
        'consent_given': prefs.getBool('privacy_consent') ?? false,
        'consent_timestamp': prefs.getString('consent_timestamp'),
        'data_retention_hours': _dataRetentionPeriod.inHours,
        'max_retained_files': _maxRetainedFiles,
        'encryption_enabled': true,
        'last_cleanup': prefs.getString('last_cleanup'),
      };
    } catch (e) {
      return {
        'error': 'Failed to get privacy status',
        'details': e.toString(),
      };
    }
  }
  
  static Future<void> _setupPrivacyPolicies() async {
    // Run cleanup periodically
    Timer.periodic(const Duration(hours: 6), (timer) async {
      await cleanupTempFiles();
      
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_cleanup', DateTime.now().toIso8601String());
    });
  }
}

class SecurityException implements Exception {
  final String message;
  
  SecurityException(this.message);
  
  @override
  String toString() => 'SecurityException: $message';
}

import 'dart:async';
