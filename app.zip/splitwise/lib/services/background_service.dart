import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:async';
import 'dart:ui' as ui;
import 'package:shared_preferences/shared_preferences.dart';
import 'notification_service.dart';

Future<void> initializeService() async {
  final service = FlutterBackgroundService();
  
  await service.configure(
    androidConfiguration: AndroidConfiguration(
      onStart: onStart,
      autoStart: true,
      isForegroundMode: true,
      notificationChannelId: 'reel_ality_check_channel',
      initialNotificationTitle: 'Reel-ality Check',
      initialNotificationContent: 'Content bias monitoring service is running',
      foregroundServiceNotificationId: 888,
    ),
    iosConfiguration: IosConfiguration(
      autoStart: true,
      onForeground: onStart,
      onBackground: onIosBackground,
    ),
  );
  
  service.startService();
}

@pragma('vm:entry-point')
void onStart(ServiceInstance service) async {
  DartPluginRegistrant.ensureInitialized();
  
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  
  await NotificationService.initialize(flutterLocalNotificationsPlugin);

  if (service is AndroidServiceInstance) {
    service.on('setAsForeground').listen((event) {
      service.setAsForegroundService();
    });

    service.on('setAsBackground').listen((event) {
      service.setAsBackgroundService();
    });
  }

  service.on('stopService').listen((event) {
    service.stopSelf();
  });

  // Main background service logic
  Timer.periodic(const Duration(seconds: 30), (timer) async {
    await _performBackgroundTasks(service);
  });

  // 72-hour cron job scheduler
  Timer.periodic(const Duration(hours: 1), (timer) async {
    await _checkAndSchedule72HourAnalysis();
  });

  // Initial notification
  await NotificationService.showSystemNotification(
    title: '🚀 Service Started',
    body: 'Reel-ality Check background service is active',
  );
}

@pragma('vm:entry-point')
Future<bool> onIosBackground(ServiceInstance service) async {
  return true;
}

Future<void> _performBackgroundTasks(ServiceInstance service) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final isMonitoring = prefs.getBool('is_monitoring') ?? false;
    
    if (isMonitoring) {
      // Check if we need to process any pending analysis
      await _checkPendingAnalysis();
      
      // Update service notification
      if (service is AndroidServiceInstance) {
        await service.setForegroundNotificationInfo(
          title: 'Reel-ality Check',
          content: 'Monitoring content for bias detection...',
        );
      }
    } else {
      // Update service notification for idle state
      if (service is AndroidServiceInstance) {
        await service.setForegroundNotificationInfo(
          title: 'Reel-ality Check',
          content: 'Service running - monitoring paused',
        );
      }
    }
  } catch (e) {
    await NotificationService.showErrorNotification(error: e.toString());
  }
}

Future<void> _checkPendingAnalysis() async {
  try {
    // Check for any pending content analysis
    final prefs = await SharedPreferences.getInstance();
    final pendingAnalysisCount = prefs.getInt('pending_analysis_count') ?? 0;
    
    if (pendingAnalysisCount > 0) {
      // Process pending analysis
      await _processPendingContent();
      
      // Update count
      await prefs.setInt('pending_analysis_count', pendingAnalysisCount - 1);
    }
  } catch (e) {
    print('Error checking pending analysis: $e');
  }
}

Future<void> _processPendingContent() async {
  try {
    // This would integrate with the actual content processing pipeline
    // For now, we'll simulate the processing
    
    // Simulate processing delay
    await Future.delayed(const Duration(seconds: 2));
    
    // Show completion notification
    await NotificationService.showAnalysisComplete(
      classification: 'Sample Category',
      confidence: 0.85,
    );
  } catch (e) {
    print('Error processing pending content: $e');
  }
}

Future<void> _checkAndSchedule72HourAnalysis() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final lastAnalysisTime = prefs.getString('last_72hour_analysis');
    final currentTime = DateTime.now();
    
    // Check if 72 hours have passed since last analysis
    if (lastAnalysisTime != null) {
      final lastAnalysis = DateTime.parse(lastAnalysisTime);
      final timeDifference = currentTime.difference(lastAnalysis);
      
      if (timeDifference.inHours >= 72) {
        await _perform72HourAnalysis();
        await prefs.setString('last_72hour_analysis', currentTime.toIso8601String());
      }
    } else {
      // First time running, set initial time
      await prefs.setString('last_72hour_analysis', currentTime.toIso8601String());
    }
  } catch (e) {
    print('Error checking 72-hour analysis: $e');
  }
}

Future<void> _perform72HourAnalysis() async {
  try {
    // Get tilt index and dominant cluster from stored data
    final prefs = await SharedPreferences.getInstance();
    final tiltIndex = prefs.getDouble('current_tilt_index') ?? 0.0;
    final dominantCluster = prefs.getString('dominant_cluster');
    
    // Generate and show 72-hour analysis notification
    await NotificationService.schedule72HourNotification(
      tiltIndex: tiltIndex,
      dominantCluster: dominantCluster,
    );
    
    // Also show immediate notification
    if (tiltIndex > 40) {
      await NotificationService.showBiasAlert(
        tiltIndex: tiltIndex,
        dominantCategory: dominantCluster ?? 'Unknown',
      );
    } else if (tiltIndex < 20) {
      await NotificationService.showPositiveReinforcement(
        tiltIndex: tiltIndex,
      );
    } else {
      await NotificationService.showSystemNotification(
        title: '📊 72-Hour Analysis Complete',
        body: 'Your content bias analysis is ready. Check the app for detailed insights.',
      );
    }
    
    print('72-hour analysis completed successfully');
  } catch (e) {
    print('Error performing 72-hour analysis: $e');
    await NotificationService.showErrorNotification(error: 'Analysis failed: $e');
  }
}

// Service control methods
class BackgroundServiceController {
  static Future<void> startMonitoring() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_monitoring', true);
    
    // Notify service
    FlutterBackgroundService().invoke('setAsForeground');
    
    await NotificationService.showMonitoringStatus(isActive: true);
  }

  static Future<void> stopMonitoring() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('is_monitoring', false);
    
    // Notify service
    FlutterBackgroundService().invoke('setAsBackground');
    
    await NotificationService.showMonitoringStatus(isActive: false);
  }

  static Future<void> scheduleImmediateAnalysis() async {
    // Force immediate 72-hour analysis for testing
    await _perform72HourAnalysis();
  }

  static Future<void> updateTiltIndex(double tiltIndex) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('current_tilt_index', tiltIndex);
  }

  static Future<void> updateDominantCluster(String cluster) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dominant_cluster', cluster);
  }

  static Future<void> addPendingAnalysis() async {
    final prefs = await SharedPreferences.getInstance();
    final currentCount = prefs.getInt('pending_analysis_count') ?? 0;
    await prefs.setInt('pending_analysis_count', currentCount + 1);
  }

  static Future<Map<String, dynamic>> getServiceStatus() async {
    final prefs = await SharedPreferences.getInstance();
    
    return {
      'is_monitoring': prefs.getBool('is_monitoring') ?? false,
      'last_72hour_analysis': prefs.getString('last_72hour_analysis'),
      'current_tilt_index': prefs.getDouble('current_tilt_index') ?? 0.0,
      'dominant_cluster': prefs.getString('dominant_cluster'),
      'pending_analysis_count': prefs.getInt('pending_analysis_count') ?? 0,
    };
  }

  static Future<void> resetServiceData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    
    await NotificationService.cancelAllNotifications();
  }

  static Future<void> testNotification() async {
    await NotificationService.showSystemNotification(
      title: '🧪 Test Notification',
      body: 'This is a test notification from Reel-ality Check',
    );
  }
}
