import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_background_service/flutter_background_service.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'dart:async';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize(
      FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin) async {
    tz.initializeTimeZones();

    const AndroidInitializationSettings initializationSettingsAndroid =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const DarwinInitializationSettings initializationSettingsIOS =
        DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const InitializationSettings initializationSettings =
        InitializationSettings(
      android: initializationSettingsAndroid,
      iOS: initializationSettingsIOS,
    );

    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: _onNotificationTapped,
    );

    await _createNotificationChannel();
  }

  static Future<void> _createNotificationChannel() async {
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'reel_ality_check_channel',
      'Reel-ality Check Notifications',
      description: 'Notifications for content bias analysis and insights',
      importance: Importance.high,
      sound: RawResourceAndroidNotificationSound('notification_sound'),
      enableLights: true,
      ledColor: 0xFF2196F3,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);
  }

  static Future<void> showInstantNotification({
    required int id,
    required String title,
    required String body,
    String? payload,
  }) async {
    const NotificationDetails notificationDetails = NotificationDetails(
      android: AndroidNotificationDetails(
        'reel_ality_check_channel',
        'Reel-ality Check Notifications',
        channelDescription: 'Notifications for content bias analysis',
        importance: Importance.high,
        priority: Priority.high,
        showWhen: true,
        icon: '@mipmap/ic_launcher',
        color: 0xFF2196F3,
        enableLights: true,
        ledColor: 0xFF2196F3,
        ledOnMs: 1000,
        ledOffMs: 500,
      ),
      iOS: DarwinNotificationDetails(
        presentAlert: true,
        presentBadge: true,
        presentSound: true,
      ),
    );

    await _flutterLocalNotificationsPlugin.show(
      id,
      title,
      body,
      notificationDetails,
      payload: payload,
    );
  }

  static Future<void> schedulePeriodicNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledTime,
    String? payload,
  }) async {
    await _flutterLocalNotificationsPlugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(scheduledTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'reel_ality_check_channel',
          'Reel-ality Check Notifications',
          channelDescription: 'Notifications for content bias analysis',
          importance: Importance.high,
          priority: Priority.high,
          showWhen: true,
          icon: '@mipmap/ic_launcher',
          color: 0xFF2196F3,
        ),
        iOS: DarwinNotificationDetails(
          presentAlert: true,
          presentBadge: true,
          presentSound: true,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      payload: payload,
      matchDateTimeComponents: DateTimeComponents.time, // Repeat daily at same time
    );
  }

  static Future<void> schedule72HourNotification({
    required double tiltIndex,
    required String? dominantCluster,
  }) async {
    final now = DateTime.now();
    final scheduledTime = now.add(const Duration(hours: 72));

    final notificationData = _generateNotificationContent(tiltIndex, dominantCluster);
    
    await schedulePeriodicNotification(
      id: 1001,
      title: notificationData['title'],
      body: notificationData['body'],
      scheduledTime: scheduledTime,
      payload: '72_hour_analysis',
    );
  }

  static Map<String, String> _generateNotificationContent(
      double tiltIndex, String? dominantCluster) {
    if (tiltIndex > 40) {
      // Alert State - High bias detected
      return {
        'title': '⚠️ High Content Bias Detected',
        'body':
            'Your content consumption shows significant bias. Consider diversifying your media diet for a balanced perspective.',
      };
    } else if (tiltIndex < 20) {
      // Equilibrium State - Well balanced
      return {
        'title': '🎉 Well Balanced Content Diet!',
        'body':
            'Great job! Your content consumption is well-balanced across different categories. Keep it up!',
      };
    } else {
      // Moderate tilt
      return {
        'title': '📊 Content Analysis Available',
        'body':
            'Your 72-hour content analysis is ready. Check your insights for detailed recommendations.',
      };
    }
  }

  static Future<void> showBiasAlert({
    required double tiltIndex,
    required String dominantCategory,
  }) async {
    await showInstantNotification(
      id: 2001,
      title: '⚠️ Algorithmic Bias Alert',
      body:
          'High concentration of $dominantCategory content detected. Your tilt index: ${tiltIndex.toStringAsFixed(1)}',
      payload: 'bias_alert',
    );
  }

  static Future<void> showPositiveReinforcement({
    required double tiltIndex,
  }) async {
    await showInstantNotification(
      id: 2002,
      title: '🌟 Great Content Balance!',
      body:
          'Your content tilt index is ${tiltIndex.toStringAsFixed(1)} - excellent balance across categories!',
      payload: 'positive_reinforcement',
    );
  }

  static Future<void> showMonitoringStatus({
    required bool isActive,
  }) async {
    if (isActive) {
      await showInstantNotification(
        id: 3001,
        title: '📱 Monitoring Started',
        body: 'Reel-ality Check is now monitoring Instagram Reels for content analysis.',
        payload: 'monitoring_started',
      );
    } else {
      await showInstantNotification(
        id: 3002,
        title: '⏸️ Monitoring Paused',
        body: 'Content monitoring has been paused. Resume to continue analysis.',
        payload: 'monitoring_stopped',
      );
    }
  }

  static Future<void> showAnalysisComplete({
    required String classification,
    required double confidence,
  }) async {
    await showInstantNotification(
      id: 4001,
      title: '✅ Analysis Complete',
      body:
          'Content classified as $classification with ${(confidence * 100).toStringAsFixed(1)}% confidence.',
      payload: 'analysis_complete',
    );
  }

  static Future<void> showSystemNotification({
    required String title,
    required String body,
  }) async {
    await showInstantNotification(
      id: 5000,
      title: title,
      body: body,
      payload: 'system_notification',
    );
  }

  static Future<void> cancelNotification(int id) async {
    await _flutterLocalNotificationsPlugin.cancel(id);
  }

  static Future<void> cancelAllNotifications() async {
    await _flutterLocalNotificationsPlugin.cancelAll();
  }

  static Future<void> getPendingNotifications() async {
    final pendingNotifications =
        await _flutterLocalNotificationsPlugin.pendingNotificationRequests();
    
    for (final notification in pendingNotifications) {
      print('Pending notification: ${notification.id}, ${notification.title}');
    }
  }

  static Future<void> _onNotificationTapped(
      NotificationResponse notificationResponse) async {
    // Handle notification tap
    final payload = notificationResponse.payload;
    
    if (payload != null) {
      switch (payload) {
        case 'bias_alert':
          // Navigate to insights screen
          break;
        case 'positive_reinforcement':
          // Navigate to insights screen
          break;
        case '72_hour_analysis':
          // Navigate to insights screen with 72-hour analysis
          break;
        case 'analysis_complete':
          // Navigate to history screen
          break;
        default:
          // Default action
          break;
      }
    }
  }

  // Background notification scheduling
  static Future<void> scheduleBackgroundNotifications() async {
    // Schedule 72-hour analysis notifications
    final now = DateTime.now();
    final next72HourTime = now.add(const Duration(hours: 72));
    
    await schedulePeriodicNotification(
      id: 6001,
      title: '📊 72-Hour Content Analysis',
      body: 'Your comprehensive content bias analysis is ready to view.',
      scheduledTime: next72HourTime,
      payload: '72_hour_analysis',
    );
  }

  // Notification for system overlay status (NFR-4 compliance)
  static Future<void> showOverlayStatus({
    required bool isActive,
  }) async {
    if (isActive) {
      // Show persistent notification for active screen capture
      await showInstantNotification(
        id: 7001,
        title: '🔴 Screen Capture Active',
        body: 'Reel-ality Check is actively analyzing content for bias detection.',
        payload: 'overlay_active',
      );
    } else {
      await cancelNotification(7001);
    }
  }

  // Error notification
  static Future<void> showErrorNotification({
    required String error,
  }) async {
    await showInstantNotification(
      id: 8001,
      title: '❌ Error Occurred',
      body: 'An error occurred during content analysis: $error',
      payload: 'error_notification',
    );
  }

  // Permission notification
  static Future<void> showPermissionNotification() async {
    await showInstantNotification(
      id: 9001,
      title: '🔐 Permissions Required',
      body: 'Please grant required permissions for content monitoring to work properly.',
      payload: 'permission_request',
    );
  }
}
