import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class TiltIndicator extends StatelessWidget {
  final double tiltIndex;
  final double size;

  const TiltIndicator({
    super.key,
    required this.tiltIndex,
    this.size = 200,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: TiltIndicatorPainter(tiltIndex: tiltIndex),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                tiltIndex.toStringAsFixed(1),
                style: TextStyle(
                  fontSize: size * 0.2,
                  fontWeight: FontWeight.bold,
                  color: _getTiltColor(tiltIndex),
                ),
              ),
              Text(
                'Tilt Index',
                style: TextStyle(
                  fontSize: size * 0.08,
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getTiltColor(double tiltIndex) {
    if (tiltIndex < 20) return Colors.green;
    if (tiltIndex < 40) return Colors.orange;
    return Colors.red;
  }
}

class TiltIndicatorPainter extends CustomPainter {
  final double tiltIndex;

  TiltIndicatorPainter({required this.tiltIndex});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width * 0.4;

    // Draw background circle
    final backgroundPaint = Paint()
      ..color = Colors.grey[200]!
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.02;

    canvas.drawCircle(center, radius, backgroundPaint);

    // Draw progress arc
    final sweepAngle = (tiltIndex / 100) * 2 * 3.14159265359;
    final progressPaint = Paint()
      ..color = _getTiltColor(tiltIndex)
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.04
      ..strokeCap = StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      -3.14159265359 / 2, // Start from top
      sweepAngle,
      false,
      progressPaint,
    );

    // Draw scale markers
    _drawScaleMarkers(canvas, center, radius, size);

    // Draw center dot
    final centerPaint = Paint()
      ..color = _getTiltColor(tiltIndex)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(center, size.width * 0.03, centerPaint);
  }

  void _drawScaleMarkers(Canvas canvas, Offset center, double radius, Size size) {
    final markerPaint = Paint()
      ..color = Colors.grey[400]!
      ..strokeWidth = size.width * 0.01;

    // Draw markers at 0, 25, 50, 75, 100
    final markers = [0.0, 0.25, 0.5, 0.75, 1.0];
    
    for (final marker in markers) {
      final angle = -3.14159265359 / 2 + (marker * 2 * 3.14159265359);
      final startOffset = Offset(
        center.dx + radius * 0.9 * cos(angle),
        center.dy + radius * 0.9 * sin(angle),
      );
      final endOffset = Offset(
        center.dx + radius * 1.1 * cos(angle),
        center.dy + radius * 1.1 * sin(angle),
      );

      canvas.drawLine(startOffset, endOffset, markerPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }

  Color _getTiltColor(double tiltIndex) {
    if (tiltIndex < 20) return Colors.green;
    if (tiltIndex < 40) return Colors.orange;
    return Colors.red;
  }
}

// Extension for cos and sin
extension MathExtension on double {
  double cos() => math.cos(this);
  double sin() => math.sin(this);
}

// Import math library
import 'dart:math' as math;
