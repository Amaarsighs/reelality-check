import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../models/reel_data.dart';

class CategoryBreakdown extends StatelessWidget {
  final List<ReelData> reelHistory;

  const CategoryBreakdown({
    super.key,
    required this.reelHistory,
  });

  @override
  Widget build(BuildContext context) {
    if (reelHistory.isEmpty) {
      return const Center(
        child: Text('No data available'),
      );
    }

    final categoryStats = _calculateCategoryStats();
    
    return Column(
      children: [
        SizedBox(
          height: 200,
          child: CustomPaint(
            painter: DonutChartPainter(categoryStats: categoryStats),
            child: const Center(),
          ),
        ),
        const SizedBox(height: 16),
        _buildCategoryList(categoryStats),
      ],
    );
  }

  Map<String, CategoryStat> _calculateCategoryStats() {
    final categoryCounts = <String, int>{};
    
    for (final reel in reelHistory) {
      if (reel.classification != null) {
        final category = reel.classification!;
        categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
      }
    }

    final total = categoryCounts.values.fold(0, (sum, count) => sum + count);
    final categoryStats = <String, CategoryStat>{};

    categoryCounts.forEach((category, count) {
      categoryStats[category] = CategoryStat(
        category: category,
        count: count,
        percentage: (count / total) * 100,
        color: _getCategoryColor(category),
      );
    });

    return categoryStats;
  }

  Widget _buildCategoryList(Map<String, CategoryStat> categoryStats) {
    final sortedCategories = categoryStats.entries.toList()
      ..sort((a, b) => b.value.count.compareTo(a.value.count));

    return Column(
      children: sortedCategories.map((entry) {
        final stat = entry.value;
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4.0),
          child: Row(
            children: [
              Container(
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                  color: stat.color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  stat.category,
                  style: const TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                ),
              ),
              Text(
                '${stat.count} (${stat.percentage.toStringAsFixed(1)}%)',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Color _getCategoryColor(String category) {
    final categoryColors = {
      'Entertainment': Colors.purple,
      'Educational': Colors.blue,
      'News_Politics': Colors.red,
      'Lifestyle': Colors.green,
      'Sports': Colors.orange,
      'Technology': Colors.indigo,
      'Fashion': Colors.pink,
      'Food': Colors.brown,
      'Travel': Colors.teal,
      'Health_Fitness': Colors.lightGreen,
    };
    
    return categoryColors[category] ?? Colors.grey;
  }
}

class CategoryStat {
  final String category;
  final int count;
  final double percentage;
  final Color color;

  CategoryStat({
    required this.category,
    required this.count,
    required this.percentage,
    required this.color,
  });
}

class DonutChartPainter extends CustomPainter {
  final Map<String, CategoryStat> categoryStats;

  DonutChartPainter({required this.categoryStats});

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final outerRadius = math.min(size.width, size.height) * 0.35;
    final innerRadius = outerRadius * 0.6;

    double startAngle = -math.pi / 2; // Start from top

    categoryStats.forEach((category, stat) {
      final sweepAngle = (stat.percentage / 100) * 2 * math.pi;
      
      // Draw donut slice
      final paint = Paint()
        ..color = stat.color
        ..style = PaintingStyle.fill;

      final path = Path();
      
      // Outer arc
      path.addArc(
        Rect.fromCircle(center: center, radius: outerRadius),
        startAngle,
        sweepAngle,
      );
      
      // Inner arc (to create donut hole)
      path.addArc(
        Rect.fromCircle(center: center, radius: innerRadius),
        startAngle + sweepAngle,
        -sweepAngle,
      );
      
      path.close();
      canvas.drawPath(path, paint);

      startAngle += sweepAngle;
    });

    // Draw center text
    _drawCenterText(canvas, center, innerRadius);
  }

  void _drawCenterText(Canvas canvas, Offset center, double innerRadius) {
    final total = categoryStats.values.fold(0, (sum, stat) => sum + stat.count);
    
    _drawText(
      canvas,
      total.toString(),
      center - Offset(0, 10),
      Colors.black,
      innerRadius * 0.3,
      FontWeight.bold,
    );

    _drawText(
      canvas,
      'Total',
      center + Offset(0, 10),
      Colors.grey[600]!,
      innerRadius * 0.15,
      FontWeight.normal,
    );
  }

  void _drawText(
    Canvas canvas,
    String text,
    Offset offset,
    Color color,
    double fontSize,
    FontWeight fontWeight,
  ) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: fontSize,
          fontWeight: fontWeight,
        ),
      ),
      textDirection: TextDirection.ltr,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      offset - Offset(textPainter.width / 2, textPainter.height / 2),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}

import 'dart:math' as math;
