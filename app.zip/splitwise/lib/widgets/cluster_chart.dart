import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'dart:math' as math;

class ClusterChart extends StatelessWidget {
  final Map<String, dynamic> clusters;
  final int? dominantCluster;

  const ClusterChart({
    super.key,
    required this.clusters,
    this.dominantCluster,
  });

  @override
  Widget build(BuildContext context) {
    if (clusters['cluster_weights'] == null) {
      return const Center(
        child: Text('No cluster data available'),
      );
    }

    return SizedBox(
      height: 200,
      child: CustomPaint(
        painter: ClusterChartPainter(
          clusters: clusters['cluster_weights'],
          dominantCluster: dominantCluster,
        ),
        child: const Center(),
      ),
    );
  }
}

class ClusterChartPainter extends CustomPainter {
  final Map<String, dynamic> clusterWeights;
  final int? dominantCluster;

  ClusterChartPainter({
    required this.clusterWeights,
    this.dominantCluster,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = math.min(size.width, size.height) * 0.35;

    // Draw pie chart
    _drawPieChart(canvas, center, radius);

    // Draw legend
    _drawLegend(canvas, size);
  }

  void _drawPieChart(Canvas canvas, Offset center, double radius) {
    double startAngle = -math.pi / 2; // Start from top

    clusterWeights.forEach((clusterId, weight) {
      final sweepAngle = (weight as double) * 2 * math.pi;
      final color = _getClusterColor(int.parse(clusterId));
      
      // Draw pie slice
      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.fill;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        true,
        paint,
      );

      // Draw border for dominant cluster
      if (dominantCluster != null && int.parse(clusterId) == dominantCluster) {
        final borderPaint = Paint()
          ..color = Colors.black
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3;

        canvas.drawArc(
          Rect.fromCircle(center: center, radius: radius),
          startAngle,
          sweepAngle,
          true,
          borderPaint,
        );
      }

      // Draw percentage text
      final midAngle = startAngle + sweepAngle / 2;
      final textOffset = Offset(
        center.dx + radius * 0.7 * math.cos(midAngle),
        center.dy + radius * 0.7 * math.sin(midAngle),
      );

      _drawText(
        canvas,
        '${(weight * 100).toStringAsFixed(1)}%',
        textOffset,
        Colors.white,
        size.width * 0.04,
      );

      startAngle += sweepAngle;
    });
  }

  void _drawLegend(Canvas canvas, Size size) {
    final legendStartY = size.height * 0.8;
    double legendX = 20;
    final legendY = legendStartY;
    final itemHeight = size.height * 0.05;
    final itemWidth = size.width * 0.15;

    clusterWeights.forEach((clusterId, weight) {
      final color = _getClusterColor(int.parse(clusterId));

      // Draw color box
      final paint = Paint()
        ..color = color
        ..style = PaintingStyle.fill;

      canvas.drawRect(
        Rect.fromLTWH(legendX, legendY, itemWidth * 0.3, itemHeight * 0.6),
        paint,
      );

      // Draw text
      _drawText(
        canvas,
        'C$clusterId',
        Offset(legendX + itemWidth * 0.4, legendY + itemHeight * 0.3),
        Colors.black,
        size.width * 0.03,
      );

      legendX += itemWidth;
    });
  }

  void _drawText(Canvas canvas, String text, Offset offset, Color color, double fontSize) {
    final textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: color,
          fontSize: fontSize,
          fontWeight: FontWeight.bold,
        ),
      ),
      textDirection: TextDirection.ltr,
    );

    textPainter.layout();
    textPainter.paint(
      canvas,
      offset - Offset(textPainter.width / 2, textPainter.height / 2),
    );
  }

  Color _getClusterColor(int clusterId) {
    final colors = [
      Colors.blue,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.red,
      Colors.teal,
      Colors.indigo,
      Colors.pink,
    ];
    return colors[clusterId % colors.length];
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}
