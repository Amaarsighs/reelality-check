from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_sslify import SSLify
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import euclidean_distances
import pickle
import os
import logging
from datetime import datetime, timedelta
import threading
import schedule
import time
from cryptography.fernet import Fernet
import speech_recognition as sr
import pytesseract
from PIL import Image
import io
import base64

app = Flask(__name__)

# Security and Configuration
CORS(app)
if os.environ.get('FLASK_ENV') != 'development':
    SSLify(app)

# Logging Configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Encryption Key (In production, store securely)
ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY', Fernet.generate_key().decode())
cipher_suite = Fernet(ENCRYPTION_KEY.encode())

# Global ML Models
tfidf_vectorizer = TfidfVectorizer(max_features=1000, stop_words='english')
knn_classifier = KNeighborsClassifier(n_neighbors=3, metric='euclidean')
kmeans_clusterer = KMeans(n_clusters=5, random_state=42)

# Training Data Categories (Content Classification)
CATEGORIES = [
    'Entertainment', 'Educational', 'News_Politics', 'Lifestyle', 
    'Sports', 'Technology', 'Fashion', 'Food', 'Travel', 'Health_Fitness'
]

# In-memory storage (In production, use PostgreSQL/MongoDB)
user_data = {}
classification_history = []
cluster_models = {}

class ContentAnalyzer:
    def __init__(self):
        self.is_trained = False
        self.load_models()
    
    def load_models(self):
        """Load pre-trained models or train with initial data"""
        try:
            if os.path.exists('models/tfidf_vectorizer.pkl'):
                with open('models/tfidf_vectorizer.pkl', 'rb') as f:
                    self.tfidf_vectorizer = pickle.load(f)
                self.is_trained = True
            else:
                self.tfidf_vectorizer = tfidf_vectorizer
                self.train_initial_models()
        except Exception as e:
            logger.error(f"Error loading models: {e}")
            self.train_initial_models()
    
    def train_initial_models(self):
        """Train models with sample data"""
        sample_texts = [
            "Amazing dance challenge viral trending entertainment",
            "Learn python programming tutorial educational coding",
            "Breaking news politics election results today",
            "Morning routine lifestyle tips self care",
            "Football match highlights sports goals",
            "Latest technology AI machine learning news",
            "Fashion trends summer outfit ideas",
            "Recipe cooking food delicious meal",
            "Travel destinations vacation holiday",
            "Workout fitness health exercise routine"
        ]
        sample_labels = list(range(10))
        
        # Train TF-IDF
        X_tfidf = self.tfidf_vectorizer.fit_transform(sample_texts)
        
        # Train k-NN Classifier
        self.knn_classifier = KNeighborsClassifier(n_neighbors=3, metric='euclidean')
        self.knn_classifier.fit(X_tfidf.toarray(), sample_labels)
        
        # Train K-Means
        self.kmeans_clusterer = KMeans(n_clusters=5, random_state=42)
        self.kmeans_clusterer.fit(X_tfidf.toarray())
        
        self.is_trained = True
        self.save_models()
    
    def save_models(self):
        """Save trained models"""
        os.makedirs('models', exist_ok=True)
        with open('models/tfidf_vectorizer.pkl', 'wb') as f:
            pickle.dump(self.tfidf_vectorizer, f)
        with open('models/knn_classifier.pkl', 'wb') as f:
            pickle.dump(self.knn_classifier, f)
        with open('models/kmeans_clusterer.pkl', 'wb') as f:
            pickle.dump(self.kmeans_clusterer, f)
    
    def extract_features(self, text_content):
        """Extract TF-IDF features from text"""
        if not text_content or not text_content.strip():
            return np.zeros((1, 1000))
        
        combined_text = f"{text_content}"
        features = self.tfidf_vectorizer.transform([combined_text])
        return features.toarray()
    
    def classify_content(self, text_content):
        """Classify content using k-NN"""
        features = self.extract_features(text_content)
        prediction = self.knn_classifier.predict(features)[0]
        probabilities = self.knn_classifier.predict_proba(features)[0]
        confidence = max(probabilities)
        
        return {
            'label': CATEGORIES[prediction],
            'confidence': float(confidence),
            'category_id': int(prediction)
        }
    
    def calculate_tilt_score(self, classification_result, user_baseline=None):
        """Calculate tilt score based on classification"""
        # Simplified tilt calculation
        category_weights = {
            'News_Politics': 0.8,
            'Entertainment': 0.3,
            'Educational': -0.2,
            'Lifestyle': 0.1,
            'Sports': 0.2,
            'Technology': -0.1,
            'Fashion': 0.1,
            'Food': 0.0,
            'Travel': 0.1,
            'Health_Fitness': -0.1
        }
        
        base_score = category_weights.get(classification_result['label'], 0.0)
        confidence_adjustment = classification_result['confidence'] * 0.2
        
        tilt_score = base_score + confidence_adjustment
        
        if user_baseline:
            tilt_score = abs(tilt_score - user_baseline)
        
        return float(tilt_score)
    
    def perform_clustering(self, user_id):
        """Perform K-Means clustering on user's content history"""
        user_history = classification_history.get(user_id, [])
        if len(user_history) < 5:
            return None
        
        # Extract features from user's history
        texts = [item['text_content'] for item in user_history[-50:]]  # Last 50 items
        
        if len(texts) < 5:
            return None
        
        X_tfidf = self.tfidf_vectorizer.transform(texts)
        
        # Perform clustering
        kmeans = KMeans(n_clusters=min(5, len(texts)), random_state=42)
        cluster_labels = kmeans.fit_predict(X_tfidf.toarray())
        
        # Calculate cluster weights
        unique_labels, counts = np.unique(cluster_labels, return_counts=True)
        cluster_weights = dict(zip(unique_labels, counts / len(cluster_labels)))
        
        # Find dominant cluster
        dominant_cluster = unique_labels[np.argmax(counts)]
        
        return {
            'cluster_labels': cluster_labels.tolist(),
            'cluster_weights': {str(k): float(v) for k, v in cluster_weights.items()},
            'dominant_cluster': int(dominant_cluster),
            'cluster_centers': kmeans.cluster_centers_.tolist(),
            'inertia': float(kmeans.inertia_)
        }

# Initialize Content Analyzer
content_analyzer = ContentAnalyzer()

def encrypt_data(data):
    """Encrypt sensitive data"""
    if isinstance(data, str):
        return cipher_suite.encrypt(data.encode()).decode()
    return data

def decrypt_data(encrypted_data):
    """Decrypt sensitive data"""
    if isinstance(encrypted_data, str):
        try:
            return cipher_suite.decrypt(encrypted_data.encode()).decode()
        except:
            return encrypted_data
    return encrypted_data

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'models_trained': content_analyzer.is_trained
    })

@app.route('/api/classify', methods=['POST'])
def classify_reel():
    """Classify reel content using k-NN"""
    try:
        data = request.get_json()
        
        if not data or 'transcript' not in data:
            return jsonify({'error': 'Missing transcript data'}), 400
        
        transcript = data['transcript']
        overlay_text = data.get('overlayText', '')
        audio_text = data.get('audioText', '')
        
        # Combine text features
        combined_text = f"{transcript} {overlay_text} {audio_text}".strip()
        
        # Classify content
        classification = content_analyzer.classify_content(combined_text)
        
        # Calculate tilt score
        tilt_score = content_analyzer.calculate_tilt_score(classification)
        
        result = {
            'classification': classification,
            'tiltScore': tilt_score,
            'timestamp': datetime.now().isoformat(),
            'processed': True
        }
        
        # Store in history
        user_id = data.get('userId', 'anonymous')
        if user_id not in classification_history:
            classification_history[user_id] = []
        
        classification_history[user_id].append({
            'timestamp': datetime.now().isoformat(),
            'text_content': combined_text,
            'classification': classification,
            'tilt_score': tilt_score
        })
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"Classification error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/insights', methods=['GET'])
def get_insights():
    """Get user insights and tilt index"""
    try:
        user_id = request.args.get('userId', 'anonymous')
        
        user_history = classification_history.get(user_id, [])
        if len(user_history) < 3:
            return jsonify({
                'tiltIndex': 0.0,
                'dominantCluster': None,
                'clusters': {},
                'message': 'Insufficient data for analysis'
            })
        
        # Perform clustering
        clustering_result = content_analyzer.perform_clustering(user_id)
        
        if not clustering_result:
            return jsonify({
                'tiltIndex': 0.0,
                'dominantCluster': None,
                'clusters': {},
                'message': 'Insufficient data for clustering'
            })
        
        # Calculate tilt index based on dominant cluster weight
        dominant_cluster = clustering_result['dominant_cluster']
        cluster_weights = clustering_result['cluster_weights']
        dominant_weight = cluster_weights.get(str(dominant_cluster), 0.0)
        
        # Tilt index calculation (variance from neutral baseline)
        neutral_baseline = 0.4  # 40% is considered neutral
        tilt_index = abs(dominant_weight - neutral_baseline) * 100
        
        return jsonify({
            'tiltIndex': round(tilt_index, 2),
            'dominantCluster': dominant_cluster,
            'clusters': clustering_result,
            'totalAnalyzed': len(user_history),
            'lastUpdated': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"Insights error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """Get user's classification history"""
    try:
        user_id = request.args.get('userId', 'anonymous')
        limit = int(request.args.get('limit', 50))
        
        user_history = classification_history.get(user_id, [])
        limited_history = user_history[-limit:] if len(user_history) > limit else user_history
        
        return jsonify({
            'history': limited_history,
            'total': len(user_history),
            'userId': user_id
        })
        
    except Exception as e:
        logger.error(f"History error: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/extract_text', methods=['POST'])
def extract_text():
    """Extract text from image/audio (OCR/ASR)"""
    try:
        data = request.get_json()
        
        if 'image' in data:
            # OCR Processing
            image_data = base64.b64decode(data['image'])
            image = Image.open(io.BytesIO(image_data))
            extracted_text = pytesseract.image_to_string(image)
            
            return jsonify({
                'type': 'ocr',
                'text': extracted_text.strip(),
                'confidence': 0.85  # Placeholder confidence score
            })
        
        elif 'audio' in data:
            # ASR Processing (simplified)
            # In production, integrate with Google Speech-to-Text or similar
            return jsonify({
                'type': 'asr',
                'text': 'Audio transcription placeholder',
                'confidence': 0.90
            })
        
        else:
            return jsonify({'error': 'No image or audio data provided'}), 400
            
    except Exception as e:
        logger.error(f"Text extraction error: {e}")
        return jsonify({'error': str(e)}), 500

def schedule_clustering_analysis():
    """Schedule periodic clustering analysis (72-hour cycle)"""
    def run_clustering():
        logger.info("Running scheduled clustering analysis")
        for user_id in classification_history.keys():
            content_analyzer.perform_clustering(user_id)
    
    # Schedule every 72 hours
    schedule.every(72).hours.do(run_clustering)
    
    while True:
        schedule.run_pending()
        time.sleep(3600)  # Check every hour

# Start background scheduler
scheduler_thread = threading.Thread(target=schedule_clustering_analysis, daemon=True)
scheduler_thread.start()

if __name__ == '__main__':
    os.makedirs('models', exist_ok=True)
    app.run(host='0.0.0.0', port=5000, ssl_context='adhoc' if os.environ.get('FLASK_ENV') != 'development' else None)
